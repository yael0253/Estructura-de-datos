package clases;

public class Nodo {
    int informacion;
    Nodo siguiente;
}
